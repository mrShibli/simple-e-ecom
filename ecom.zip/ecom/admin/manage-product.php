<?php
$views = "manage-product";
include("templates.php");