<?php
$views = "manage-cat";
include("templates.php");