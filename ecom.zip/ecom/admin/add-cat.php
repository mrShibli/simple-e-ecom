<?php
$views = "add-cat";
include("templates.php");