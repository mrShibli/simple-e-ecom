<?php
$views = "edit-product";
include("templates.php");