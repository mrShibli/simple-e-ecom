<?php
$views = "edit-cat";
include("templates.php");