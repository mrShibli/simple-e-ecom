<?php
$views = "manage-user";
include("templates.php");