<?php
$views = "dashboard";
include("templates.php");