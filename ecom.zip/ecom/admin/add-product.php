<?php
$views = "add-product";
include("templates.php");